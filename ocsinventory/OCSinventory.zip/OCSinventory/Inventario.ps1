﻿#######################################################################
# Ejecución del agente de OCS Inventory y envío de datos al servidor
#######################################################################
#
# Solicitamos y validamos la dirección IP del servidor
#
$pattern = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
$IP_valida= $false

while($IP_valida -eq $false){
  $IP = Read-Host -Prompt "Indica la dirección IP del servidor OCS Inventory"
  $IP_valida = $IP -match $pattern
}
#
# Comprobamos conexión con el servidor
#
Write-Host "-----------------------------------------------------"
Write-Host "Comprobando conexión con servidor $IP . . ."
ping $IP -w 2 | Out-Null
if($LASTEXITCODE -ne 0) {

    Write-Host "Imposible establecer conexión con el servidor"
    Write-Host "-----------------------------------------------------"
    }
    else {
    Write-Host "Coexión establecida con el servidor"
    Write-Host "-----------------------------------------------------"
#
#
# Enviamos inventario al servidor
#
    Write-Host "Enviando inventario . . ."
    .\ocsinventory.exe /SERVER:$IP
    
}
Write-Host "Revisa fichero de log para ver el resultado. Pulsa una tecla para salir."
[void][System.Console]::ReadKey($true)